package p1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class OperationClass implements UserInterface {
List<User> userList=new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	
	@Override
	public void addUser(String type,int limit) {

		
		System.out.println("enter name");
		String userName=sc.nextLine();
		System.out.println("enter address");
		String address=sc.nextLine();
		System.out.println("enter mobile no.");
		int mobileNo=Integer.parseInt(sc.nextLine());
		int userId = (int) (Math.random() * 100);
		
		if(type.equalsIgnoreCase("commercial")&&limit>100000)
		{
			User u=new Commercial(userId, userName, address, mobileNo, limit);
			userList.add(u);
			try {
				fileHandling(userName, address, limit, mobileNo);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(type.equalsIgnoreCase("residential")&&limit<100000)
		{
		User u=new Residential(userId, userName, address, mobileNo, limit);
		userList.add(u);
		try {
			fileHandling(userName, address, limit, mobileNo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}

	@Override
	public void showUser() {
		
		for (User user : userList) {
			
			System.out.println("user ID is:"+user.getUserId());
			System.out.println("user Name is:"+user.getUserName());
			System.out.println("user address is:"+user.getAddress());
			System.out.println();
			System.out.println(user);
		}
		
	}

	@Override
	public void searchUser(String name) {
		
		
		for (User user : userList) {
			
		if(user.getUserName().equals(name)){
		System.out.println("user ID is:"+user.getUserId());
		System.out.println("user Name is:"+user.getUserName());
		System.out.println("user address is:"+user.getAddress());
		System.out.println("Rest Details:"+user);
	}
			
		}

	}
	
	public void fileHandling(String username, String address, int limit,int mobile) throws IOException {
		Date date = new Date();
		File file = new File(username);
		FileWriter fw = new FileWriter(file, true);
		BufferedWriter bw = new BufferedWriter(fw);
		fw.write("File name:" + username + ".txt" + "\n");
		fw.write("Mobile Number:" + mobile + "\n");
		fw.write("limit:" + limit + "\n");
		fw.write("Date is:"+date + "\n");
		fw.write("address:" + address + "\n");
		fw.close();
		System.out.println("File updated");

	}

}
