package p1;

public interface MainOperation {

	public void findBySkill();
	
	public void findBySkill2();
}
