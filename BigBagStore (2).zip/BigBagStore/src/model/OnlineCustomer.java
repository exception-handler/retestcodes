package model;

public class OnlineCustomer extends Customer{

	private String discountCoupon;

	public String getDiscountCoupon() {
		return discountCoupon;
	}

	public void setDiscountCoupon(String discountCoupon) {
		this.discountCoupon = discountCoupon;
	}

	@Override
	public String toString() {
		return "OnlineCustomer [discountCoupon=" + discountCoupon + "]";
	}

	public OnlineCustomer(String discountCoupon) {
		super();
		this.discountCoupon = discountCoupon;
	}

	public OnlineCustomer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OnlineCustomer(String customerName, String customerType) {
		super(customerName, customerType);
		// TODO Auto-generated constructor stub
	}

	public OnlineCustomer(String customerName, String customerType, String discountCoupon) {
		super(customerName, customerType);
		this.discountCoupon = discountCoupon;
	}

	
}
