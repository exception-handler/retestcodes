package p1;

import java.util.Comparator;

public class SortByCurSalary implements Comparator<JobApp> {

	@Override
	public int compare(JobApp o1, JobApp o2) {
		if (o1.getCurrentSalary() == o2.getCurrentSalary())
			return 0;
		else if (o1.getCurrentSalary() > o2.getCurrentSalary())
			return 1;
		else
			return -1;
	}

}
