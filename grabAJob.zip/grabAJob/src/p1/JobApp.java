package p1;

public class JobApp implements Comparable<JobApp>{

	private String username;
	private int yearOfExperience;
	private int currentSalary;
	private int expectedSalary;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getYearOfExperience() {
		return yearOfExperience;
	}
	public void setYearOfExperience(int yearOfExperience) {
		this.yearOfExperience = yearOfExperience;
	}
	public int getCurrentSalary() {
		return currentSalary;
	}
	public void setCurrentSalary(int currentSalary) {
		this.currentSalary = currentSalary;
	}
	public int getExpectedSalary() {
		return expectedSalary;
	}
	public void setExpectedSalary(int expectedSalary) {
		this.expectedSalary = expectedSalary;
	}
	public JobApp(String username, int yearOfExperience, int currentSalary, int expectedSalary) {
		super();
		this.username = username;
		this.yearOfExperience = yearOfExperience;
		this.currentSalary = currentSalary;
		this.expectedSalary = expectedSalary;
	}
	@Override
	public String toString() {
		return "JobApp [username=" + username + ", yearOfExperience=" + yearOfExperience + ", currentSalary="
				+ currentSalary + ", expectedSalary=" + expectedSalary + "]";
	}
	public JobApp() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int compareTo(JobApp o) {
		if(this.yearOfExperience>o.yearOfExperience)
		return 1;
		if(this.yearOfExperience==o.yearOfExperience)
		return 0;
		else 
			return -1;
	}
	
	
}
