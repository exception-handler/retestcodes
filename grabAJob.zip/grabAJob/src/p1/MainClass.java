package p1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) throws IOException {
		
		File f=new File("abc.txt");
		String str;
		FileReader fr;
		try {
			fr = new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			while((str=br.readLine())!=null)
			{
				System.out.println(str);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Scanner sc = new Scanner(System.in);
		MainOperation runner=new MainOperations();
		while (true) {
			System.out.println("enter 1 to search user on the basis of primary skill");
			System.out.println("enter 2 to search user on the basis of primary skill and "
					+ "differnce between current and expected salary");
			System.out.println("enter 0 to exit");

			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				runner.findBySkill();
				break;
			case 2:
				runner.findBySkill2();
				break;

			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}
		} // while ends

	}
}
