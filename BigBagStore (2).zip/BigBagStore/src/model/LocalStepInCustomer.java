package model;

public class LocalStepInCustomer extends Customer {
private int maxCreditLimit;

public int getMaxCreditLimit() {
	return maxCreditLimit;
}

public void setMaxCreditLimit(int maxCreditLimit) {
	this.maxCreditLimit = maxCreditLimit;
}

@Override
public String toString() {
	return "LocalStepInCustomer [maxCreditLimit=" + maxCreditLimit + "]";
}

public LocalStepInCustomer(int maxCreditLimit) {
	super();
	this.maxCreditLimit = maxCreditLimit;
}

public LocalStepInCustomer() {
	super();
	// TODO Auto-generated constructor stub
}

public LocalStepInCustomer(String customerName, String customerType, int maxCreditLimit) {
	super(customerName, customerType);
	this.maxCreditLimit = maxCreditLimit;
}


}
