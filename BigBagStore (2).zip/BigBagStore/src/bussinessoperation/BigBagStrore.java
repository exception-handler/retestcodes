package bussinessoperation;

import java.io.IOException;
import java.util.Scanner;

import model.Customer;
import model.LocalStepInCustomer;
import model.OnlineCustomer;
import userexception.UserException;

public class BigBagStrore {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String customerType = null;
		BigBagStoreOperations operation = new BigBagStoreOperations();
		while (true) {
			System.out.println("enter 1 to add the customer");
			System.out.println("enter 2 to count customer");
			System.out.println("enter 3 to make payment");
			System.out.println("enter 4 to view all customers");
			System.out.println("enter 0 to exit");

			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				System.out.println("inside case 1");

				System.out.println("enter 1 to add online customer");
				System.out.println("enter 2 to add Local Step In customer");

				int choice1 = Integer.parseInt(sc.nextLine());
				switch (choice1) {
				case 1:
					System.out.println("enter customer name");
					String onlineCustomer = sc.nextLine();
					Customer c = new OnlineCustomer(onlineCustomer, "online", "10%");
					operation.addCustomer(c);
					break;

				case 2:

					System.out.println("enter customer name");
					String localStrpInCustomer = sc.nextLine();
					Customer c1 = new LocalStepInCustomer(localStrpInCustomer, "localStepIn", 10000);
					operation.addCustomer(c1);
					break;

				default:
					break;

				}

				break;
			case 2:
				System.out.println("inside case 2");
				String type = null;
				System.out.println("enter 1 to count online customer");
				System.out.println("enter 2 to count Local Step In customer");

				int choice2 = Integer.parseInt(sc.nextLine());
				switch (choice2) {
				case 1:
					type = "online";
					operation.countCustomer(type);
					break;

				case 2:
					type = "localStepIn";
					operation.countCustomer(type);
					break;

				default:
					break;

				}
				break;
			case 3:
				System.out.println("inside case 3");
				System.out.println("enter 1 for online customer");
				System.out.println("enter 2 for Local Step In customer");

				int choice3 = Integer.parseInt(sc.nextLine());
				switch (choice3) {
				case 1:
					type = "online";
					try {
						operation.doPayment(type);
					} catch (UserException e) {
						// TODO Auto-generated catch block
						System.out.println(e);
					}
					break;

				case 2:
					type = "localStepIn";
					try {
						operation.doPayment(type);
					} catch (UserException e) {
						// TODO Auto-generated catch block
						System.out.println(e);
					}
					break;

				default:
					break;

				}
				break;
			case 4:
				System.out.println("inside case 4");
				operation.viewCustomer();
				break;
			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}
		} // while ends

	}// main ends

}
