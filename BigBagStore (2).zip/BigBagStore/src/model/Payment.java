package model;

public interface Payment {

	public boolean makePayment(String paymentMode);
}
