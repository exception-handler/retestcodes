package p1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		Main m = new Main();
		String path = null;
		while (true) {
			System.out.println("====MENU====");
			System.out.println("1. tocheck if folder exists:");
			System.out.println("2. to folder content:");
			System.out.println("3. display:");
			System.out.println("4. create file:");
			// File file = new File("javaFile.txt");
			List<File> file = new ArrayList<>();

			file.add(new File("D:\\software\\tomcat\\apache-tomcat-7.0.82\\apache-tomcat-7.0.82\\bin"));
			int ch = Integer.parseInt(sc.nextLine());
			switch (ch) {
			case 1:
				System.out.println("enter path of folder");
				path = sc.nextLine();
				boolean exists = m.isFolderExist(path);
				if (exists) {
					System.out.println("folder exists");

					File folder = new File(path);
					File[] listOfFiles = folder.listFiles();
					System.out.println("--------------Folder are as followa---------------");
					for (File file2 : listOfFiles) {
						System.out.println(file2);

					}

				} else {
					System.out.println("folder dosent exists");
				}
				break;
			case 2:
				m.getFolderContents(path);
				break;
			case 3:
				m.display(file);
				break;
			case 4:
				m.createFile(file);
				break;
			case 0:
				System.exit(0);
				break;
			default:
				System.out.println("Wrong choice");

			}// switch end
		} // while end

	}

	public boolean isFolderExist(String path) {
		File file = new File(path);
		boolean exists = file.exists();
		return exists;
	}

	public List<File> getFolderContents(String path) {

		return null;

	}

	public void display(List<File> file) throws IOException {
		FileReader fr = new FileReader("ABC.txt");
		BufferedReader br = new BufferedReader(fr);
		String f = "";
		while ((f = br.readLine()) != null) {
			System.out.println(f + "\n");
		}
		fr.close();
	}

	public void createFile(List<File> file) throws IOException {
		File file1 = new File("ABC.txt");

		FileWriter fw = new FileWriter("ABC.txt");

		for (int i = 0; i < file.size(); i++) {
			File file2 = new File("" + file.get(i));
			String arr[] = file2.list();
			for (String str : arr) {
				fw.write(str + "\n");
			}

		}

		fw.close();

		System.out.println("entry added");
	}
}
