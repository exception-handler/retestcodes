package model;

public abstract class Customer implements Payment {

	private String customerName;
	private String customerType;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerType=" + customerType + "]";
	}
	public Customer(String customerName, String customerType) {
		super();
		this.customerName = customerName;
		this.customerType = customerType;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean makePayment(String paymentMode) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	
}
