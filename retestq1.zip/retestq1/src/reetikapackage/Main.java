package reetikapackage;

import java.util.HashSet;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		
		Main runner=new Main();
		
		int result[]=runner.removeDuplicate(new int[] {1,1,2,3,3,1,5,6,5});
		System.out.println("--------------------------------------");
		for (int i : result) {
			System.out.println(i);
		}
	}
	
	public int[] removeDuplicate(int arr[])
	{
		Set<Integer> set=new HashSet<>();
		
		for (int i : arr) {
			set.add(i);
		}
		
		int arr1[]=new int[set.size()];
		 int a=0;
		 
		 for(Integer i:set)
		 {
			 arr1[a]=i;
			 a++;
		 }
		 
		
		return arr1;
		
	}

}
