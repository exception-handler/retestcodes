package bussinessoperation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import model.Customer;
import userexception.UserException;

public class BigBagStoreOperations {

	Map<Integer, Customer> map = new HashMap<>();
	Scanner sc = new Scanner(System.in);
	int onlineCounter = 0;
	int stepInCounter = 0;

	public void addCustomer(Customer c) {
		int x = (int) (Math.random() * 100);
		if (c.getCustomerType().equalsIgnoreCase("online")) {
			map.put(x, c);
			System.out.println("Online customer added with id :" + x);
			onlineCounter++;
		}

		if (c.getCustomerType().equalsIgnoreCase("localStepIn")) {
			map.put(x, c);
			System.out.println("localStepIn customer added with id :" + x);
			stepInCounter++;
		}
	}

	public void viewCustomer() {
		Set<Integer> set = map.keySet();
		for (Integer integer : set) {
			Customer c = map.get(integer);
			System.out.println("customer name is: " + c.getCustomerName());
			System.out.println("customer type is: " + c.getCustomerType());
			System.out.println(c);
		}

		/*
		 * System.out.println("---------------------------------------------");
		 * 
		 * Iterator<Integer> itr = set.iterator(); while (itr.hasNext()) {
		 * Customer c = map.get(itr.next());
		 * System.out.println("customer name is: " + c.getCustomerName());
		 * System.out.println("customer type is: " + c.getCustomerType());
		 * System.out.println(c); }
		 */

	}

	public void countCustomer(String customerType) {
		if (customerType.equalsIgnoreCase("online")) {

			System.out.println("total count of online customer are: " + onlineCounter);
		}

		if (customerType.equalsIgnoreCase("localStepIn")) {

			System.out.println("total count of localStepIn customer are: " + stepInCounter);

		}
	}

	public void doPayment(String customerType) throws IOException, UserException {
		if (customerType.equalsIgnoreCase("online")) {

			System.out.println("Welcome online customer for payment");
			System.out.println("enter username");
			String username = sc.nextLine();

			Set<Integer> set = map.keySet();
			for (Integer integer : set) {
				Customer c = map.get(integer);
				if (c.getCustomerName().equals(username)) {
					System.out.println("enter amount");
					float amount = Float.parseFloat(sc.nextLine());
					String paymentMode = null;
					while (true) {
						System.out.println("enter 1 for Internet Banking");
						System.out.println("enter 2 for PAYTM");

						int choice = Integer.parseInt(sc.nextLine());
						switch (choice) {
						case 1:

							fileHandling(username, "Internet Banking", amount);
							break;

						case 2:
							fileHandling(username, "PAYTM", amount);
							break;

						case 0:
							System.exit(0);
							break;

						default:
							System.out.println("Wrong choice");
							break;

						}// switch ends

					} // while ends

				} // if ends

				else {
					throw new UserException("Invalid User");
				} // else ends
			} // for ends

		}

		if (customerType.equalsIgnoreCase("localStepIn")) {

			System.out.println("Welcome Local StepIn customer for payment");
			System.out.println("enter username");
			String username = sc.nextLine();
			Set<Integer> set = map.keySet();
			for (Integer integer : set) {
				Customer c = map.get(integer);
				if (c.getCustomerName().equals(username)) {
					System.out.println("enter amount");
					float amount = Float.parseFloat(sc.nextLine());
					String paymentMode = null;

					while (true) {
						System.out.println("enter 1 for Internet Banking");
						System.out.println("enter 2 for PAYTM");
						System.out.println("enter 3 for CASH");
						System.out.println("enter 4 for CREDIT CARD");
						int choice = Integer.parseInt(sc.nextLine());
						switch (choice) {
						case 1:
							fileHandling(username, "Internet Banking", amount);
							break;

						case 2:
							fileHandling(username, "PAYTM", amount);
							break;
						case 3:
							fileHandling(username, "CASH", amount);
							break;

						case 4:
							fileHandling(username, "CREDIT CARD", amount);
							break;
						case 0:
							System.exit(0);
							break;

						default:
							System.out.println("wrong choice");
							break;

						}// switch ends

					} // while ends

				} // if ends

				else {
					throw new UserException("Invalid User");
				} // else ends
			} // for ends

		} // if ends for local step in customer
	}// do payment ends

	public void fileHandling(String username, String paymentMode, Float amount) throws IOException {
		Date date = new Date();
		File file = new File("ABC.txt");
		FileWriter fw = new FileWriter(file, true);
		BufferedWriter bw = new BufferedWriter(fw);
		fw.write("File name:" + username + ".txt" + "\n");
		fw.write("Date of bill:" + date + "\n");
		fw.write("Amount:" + amount + "\n");
		fw.write("Payment Mode:" + paymentMode + "\n");
		fw.close();
		System.out.println("File updated");

	}
}
