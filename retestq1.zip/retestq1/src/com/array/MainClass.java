package com.array;

import java.util.Arrays;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		int arr1[]=new int[5];
		
		int length=arr1.length;
		System.out.println(length);
		
		for (int i = 0; i < arr1.length; i++) {
			System.out.println("enter element "+i);
			arr1[i]=Integer.parseInt(sc.nextLine());
			
			
		}
		
		for (int i = 0; i < arr1.length; i++) {
			System.out.println("input array element "+i+" is : "+arr1[i]);
		}
		
		
		Arrays.sort(arr1);
		
		int j = 0;
		int i = 1;
		
		while (i < arr1.length)
		{
			if (arr1[i] == arr1[j])
			{
				i++;
			}
			else
			{
				arr1[++j] = arr1[i++];
			}
		}
		
		int[] output = new int[j + 1];
		
		for (int k = 0; k < output.length; k++)
		{
			output[k] = arr1[k];
		}
		
		System.out.print("\nOutput Elements after removing duplicates: \n");
		for (int o : output)
		{
			System.out.print(o + " ");
		}
		
	}
	
	

}
