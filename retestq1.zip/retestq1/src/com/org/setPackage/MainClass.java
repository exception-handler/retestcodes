package com.org.setPackage;

import java.util.HashSet;

import java.util.Set;

public class MainClass {

	 public static void main(String[] args) {
		MainClass m=new MainClass();
		int arr1[]=m.removeDuplicacy(new int[]{1,2,3,4,1,5,3,6,9,2,1});
		for(int a:arr1)
		{
			System.out.print(a+" ");
		}
	}//end main
	 
	 public int[] removeDuplicacy(int arr[])
	 {
		 Set<Integer> set=new HashSet<>();
		 
		 for(int a:arr)
		 {
			 set.add((Integer)a);
		 }//end forEach
		 
		 int arr1[]=new int[set.size()];
		 int a=0;
		 
		 for(Integer i:set)
		 {
			 arr1[a]=i;
			 a++;
		 }
		 
		 return arr1;
	 }//end remove
	
}
