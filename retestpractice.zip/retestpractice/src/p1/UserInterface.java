package p1;

public interface UserInterface {

	public void addUser(String type,int limit);
	public void showUser();
	public void searchUser(String name);
}
