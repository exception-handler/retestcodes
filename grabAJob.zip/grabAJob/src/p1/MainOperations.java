package p1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.TreeSet;

import utility.Connector;

public class MainOperations implements MainOperation {
	Connection con=null;
	TreeSet<JobApp> tree=new TreeSet<>();
	Scanner sc=new Scanner(System.in);
	
	@Override
	public void findBySkill() {
		
		con=Connector.connection();
		System.out.println("enter skill");
		String skill=sc.nextLine();
		String query = "select * from job_application where username in(select username from skills where skill='"
				+ skill + "')";
		
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String username=rs.getString(1);
				int yearOfExp=rs.getInt(2);
				int currentSalary=rs.getInt(3);
				int expectedSalary=rs.getInt(4);
				
				JobApp job=new JobApp(username, yearOfExp, currentSalary, expectedSalary);
				tree.add(job);
				System.out.println(job);
				
				System.out.println(rs.getString(1));
				System.out.println(rs.getInt(2));
				System.out.println(rs.getInt(3));
				System.out.println(rs.getInt(4));
				System.out.println("----------------------------");
				
				
			}
			System.out.println(tree);
		
			
			while (true) {
				System.out.println("enter 1 to sort on the basis of year of experience");
				System.out.println("enter 2 to sort on current salary");
				System.out.println("enter 0 to exit");

				int choice = Integer.parseInt(sc.nextLine());
				switch (choice) {
				case 1:
					System.out.println("sorting on the basis of year of experience");
					System.out.println(tree);
					break;
				case 2:
					TreeSet<JobApp> jobs1 = new TreeSet<JobApp>(new SortByCurSalary());
					jobs1.addAll(tree);
					System.out.println(jobs1);
					break;
			
				case 0:
					System.exit(0);

				default:
					System.out.println("Wrong choice");
					break;
				}
			} // while ends

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void findBySkill2() {
	
		con=Connector.connection();
	}

}
