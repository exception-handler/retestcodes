package p1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;




public class MainClass {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		String type=null;
		OperationClass operation=new OperationClass();
		while (true) {
			System.out.println("enter 1 to add User");
			System.out.println("enter 2 to show User");
			System.out.println("enter 3 to search User");
			System.out.println("enter 0 to exit");

			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				System.out.println("enter limit for new user :-"
						+ " if commercial limit should be greater than 100000"
						+ "and for residential user limit should be less than 100000");
				int limit=Integer.parseInt(sc.nextLine());
			
			if(limit>=100000){
					type="commercial";	
					operation.addUser(type,limit);
				
			}

				if(limit<100000){
					type="residential";
					operation.addUser(type,limit);
				}
				break;
			case 2:
				operation.showUser();
				break;
			case 3:
				System.out.println("enter name to be searched");
				String name=sc.nextLine();
				operation.searchUser(name);
				break;
			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}
		} // while ends

	}
	
}

