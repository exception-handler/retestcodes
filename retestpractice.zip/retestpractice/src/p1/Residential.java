package p1;

public class Residential extends User {


	
	private int mobileNo;
	private int creditLimit;
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(int creditLimit) {
		this.creditLimit = creditLimit;
	}
	@Override
	public String toString() {
		return "Residential [mobileNo=" + mobileNo + ", creditLimit=" + creditLimit + "]";
	}
	public Residential(int userId, String userName, String address, int mobileNo, int creditLimit) {
		super(userId, userName, address);
		this.mobileNo = mobileNo;
		this.creditLimit = creditLimit;
	}
	public Residential() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Residential(int userId, String userName, String address) {
		super(userId, userName, address);
		// TODO Auto-generated constructor stub
	}
	
	
}
